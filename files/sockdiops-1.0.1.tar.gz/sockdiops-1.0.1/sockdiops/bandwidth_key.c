/*
 * $Id: bandwidth_key.c,v 1.11 2013/08/19 06:55:55 michaels Exp $
 *
 * Copyright (c) 2001, 2009, 2011
 *      Inferno Nettverk A/S, Norway.  All rights reserved.
 */

#include "common.h"

static const char rcsid[] =
"$Id: bandwidth_key.c,v 1.11 2013/08/19 06:55:55 michaels Exp $";

const licensekey_t *module_bandwidth_keyv = NULL;
const size_t       module_bandwidth_keyc  = 0;
